#pragma once

#define HTTP_SERVER "94.156.202.19"
#define HTTP_PORT 1388

#define TFTP_SERVER "94.156.202.19"
